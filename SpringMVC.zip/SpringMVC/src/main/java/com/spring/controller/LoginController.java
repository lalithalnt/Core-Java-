//http://www.codejava.net/frameworks/spring/spring-mvc-form-validation-example-with-bean-validation-api
package com.spring.controller;

import java.util.Map;

import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.model.LoginUser;


@Controller
public class LoginController {
	

	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String getLoginDetails(Map<String,Object> model)
	{
		LoginUser loguser=new LoginUser();
		model.put("loginForm", loguser);
		return "loginform";
		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String processLoginDetails(@Valid @ModelAttribute("loginForm")LoginUser loginForm,BindingResult result,Map<String,Object> model)
	{
		if(result.hasErrors()){
			//loginform page name i.e index page prefix
			return "loginform";
		}
		//loginsuccess page name i.e prefix loginsuccess.jsp
		return "loginsuccess";
		
	}
}
