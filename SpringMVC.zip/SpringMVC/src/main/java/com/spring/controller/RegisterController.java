package com.spring.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.model.LoginUser;
import com.spring.model.RegisterUser;

@Controller
public class RegisterController {

	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String getRegisterDetails(Map<String,Object> model)
	{
		RegisterUser reguser=new RegisterUser();
		model.put("regForm", reguser);
		return "regform";
		
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String processRegisterDetails(@Valid @ModelAttribute("regForm")RegisterUser regForm,BindingResult result,Map<String,Object> model)
	{
		if(result.hasErrors()){
			//loginform page name i.e index page prefix
			return "regform";
		}
		//loginsuccess page name i.e prefix loginsuccess.jsp

		return "regsuccess";
		
	}
	
}
//https://www.roseindia.net/tutorial/spring/spring3/web/spring-3-mvc-registration-example.html
